package com.example.ui

import android.text.format.DateUtils
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.CalorieEntry
import com.example.data.TrackerRepository
import com.example.data.UserGoal
import com.example.data.WeightEntry
import com.example.network.Content
import com.example.network.FoodNutritionResponse
import com.example.network.GeminiRequest
import com.example.network.GenerationConfig
import com.example.network.Part
import com.example.network.RetrofitClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Calendar

sealed interface SearchState {
    object Idle : SearchState
    object Loading : SearchState
    data class Success(val food: FoodNutritionResponse) : SearchState
    data class Error(val message: String) : SearchState
}

class TrackerViewModel(private val repository: TrackerRepository) : ViewModel() {

    // --- State flows ---
    val allCalorieEntries: StateFlow<List<CalorieEntry>> = repository.allCalorieEntries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allWeightEntries: StateFlow<List<WeightEntry>> = repository.allWeightEntries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userGoal: StateFlow<UserGoal> = repository.userGoalFlow
        .map { it ?: UserGoal() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserGoal())

    private val _searchState = MutableStateFlow<SearchState>(SearchState.Idle)
    val searchState: StateFlow<SearchState> = _searchState.asStateFlow()

    // --- Daily summary calculations ---
    val todayCalorieTotal: StateFlow<Int> = allCalorieEntries.map { entries ->
        entries.filter { isToday(it.timestamp) }.sumOf { it.calories }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val todayProteinTotal: StateFlow<Double> = allCalorieEntries.map { entries ->
        entries.filter { isToday(it.timestamp) }.sumOf { it.protein }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val todayFatTotal: StateFlow<Double> = allCalorieEntries.map { entries ->
        entries.filter { isToday(it.timestamp) }.sumOf { it.fat }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val todayCarbsTotal: StateFlow<Double> = allCalorieEntries.map { entries ->
        entries.filter { isToday(it.timestamp) }.sumOf { it.carbs }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Category tracking summaries
    val fruitsTotalToday: StateFlow<Int> = allCalorieEntries.map { entries ->
        entries.filter { isToday(it.timestamp) && it.category == "Meyvələr" }.sumOf { it.calories }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val veggiesTotalToday: StateFlow<Int> = allCalorieEntries.map { entries ->
        entries.filter { isToday(it.timestamp) && it.category == "Tərəvəzlər" }.sumOf { it.calories }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val fastFoodTotalToday: StateFlow<Int> = allCalorieEntries.map { entries ->
        entries.filter { isToday(it.timestamp) && it.category == "Fast-Food" }.sumOf { it.calories }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val otherTotalToday: StateFlow<Int> = allCalorieEntries.map { entries ->
        entries.filter { isToday(it.timestamp) && it.category == "Digər" }.sumOf { it.calories }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // --- Search Food via Gemini AI with Offline fallback ---
    fun searchFood(query: String) {
        if (query.isBlank()) {
            _searchState.value = SearchState.Idle
            return
        }

        _searchState.value = SearchState.Loading

        viewModelScope.launch {
            try {
                val apiKey = BuildConfig.GEMINI_API_KEY
                if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                    // Predefined Azerbaijani foods for offline/no-key usage
                    val fallback = getOfflineFood(query)
                    if (fallback != null) {
                        _searchState.value = SearchState.Success(fallback)
                    } else {
                        // Dynamically mock if not in dictionary
                        _searchState.value = SearchState.Success(generateMockFood(query))
                    }
                    return@launch
                }

                val prompt = """
                    Sən qida mütəxəssisisən. İstifadəçinin axtardığı qidanın nutrition (bəslənmə) məlumatlarını təhlil et və yalnız aşağıdakı JSON formatında cavab ver. Cavabda heç bir Markdown və ya əlavə mətn olmamalıdır, yalnız təmiz JSON olmalıdır. Dil Azərbaycan dilində olmalıdır.

                    Qida adı: "$query"

                    JSON formatı:
                    {
                      "name": "Qidanın adı",
                      "category": "Qrupu (bu dörddən biri olmalıdır: 'Meyvələr', 'Tərəvəzlər', 'Fast-Food', 'Digər')",
                      "calories": 100g və ya 1 ədəd üçün kalori miqdarı (tam ədəd),
                      "protein": protein miqdarı (qramla, məsələn 0.3),
                      "fat": yağ miqdarı (qramla, məsələn 0.2),
                      "carbs": karbohidrat miqdarı (qramla, məsələn 14.0),
                      "vitamins": "Vitaminlərin siyahısı, məsələn: C, B, Kaliyum",
                      "benefits": "Sağlamlığa faydaları (qısa və aydın cümlə)",
                      "consequences": "Hər gün yeyilsə nə olar (qısa və maraqlı məlumat)"
                    }
                """.trimIndent()

                val request = GeminiRequest(
                    contents = listOf(Content(parts = listOf(Part(text = prompt)))),
                    generationConfig = GenerationConfig(responseMimeType = "application/json")
                )

                val response = withContext(Dispatchers.IO) {
                    RetrofitClient.service.generateContent(apiKey, request)
                }

                val jsonText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (!jsonText.isNullOrEmpty()) {
                    val parsed = withContext(Dispatchers.Default) {
                        RetrofitClient.parsedMoshi.adapter(FoodNutritionResponse::class.java).fromJson(jsonText)
                    }
                    if (parsed != null) {
                        _searchState.value = SearchState.Success(parsed)
                    } else {
                        throw Exception("Düzgün JSON formatı alınmadı")
                    }
                } else {
                    throw Exception("Modeldən cavab gəlmədi")
                }
            } catch (e: Exception) {
                // If anything goes wrong, use offline database/generator
                val fallback = getOfflineFood(query) ?: generateMockFood(query)
                _searchState.value = SearchState.Success(fallback)
            }
        }
    }

    fun clearSearch() {
        _searchState.value = SearchState.Idle
    }

    // --- Room database actions ---
    fun logCalorie(name: String, calories: Int, category: String, p: Double, f: Double, c: Double, b: String?, cons: String?, vit: String?) {
        viewModelScope.launch {
            repository.insertCalorieEntry(
                CalorieEntry(
                    name = name,
                    calories = calories,
                    category = category,
                    protein = p,
                    fat = f,
                    carbs = c,
                    benefits = b,
                    consequences = cons,
                    vitamins = vit
                )
            )
        }
    }

    fun deleteLoggedCalorie(id: Int) {
        viewModelScope.launch {
            repository.deleteCalorieEntryById(id)
        }
    }

    fun logWeight(weight: Double) {
        viewModelScope.launch {
            repository.insertWeightEntry(WeightEntry(weight = weight))
            // Also update basic goal currentWeight
            val currentGoal = repository.getUserGoal() ?: UserGoal()
            val updated = currentGoal.copy(weight = weight)
            val updatedLimit = if (updated.isAutoCalculate) calculateMifflinLimit(updated) else updated.dailyCalorieLimit
            repository.insertUserGoal(updated.copy(dailyCalorieLimit = updatedLimit))
        }
    }

    fun deleteWeightLog(id: Int) {
        viewModelScope.launch {
            repository.deleteWeightEntryById(id)
        }
    }

    fun updateGoal(calorieLimit: Int, autoCalculate: Boolean, weight: Double, height: Double, age: Int, gender: String, activity: String) {
        viewModelScope.launch {
            var newGoal = UserGoal(
                dailyCalorieLimit = calorieLimit,
                isAutoCalculate = autoCalculate,
                weight = weight,
                height = height,
                age = age,
                gender = gender,
                activityLevel = activity
            )
            val finalLimit = if (autoCalculate) calculateMifflinLimit(newGoal) else calorieLimit
            newGoal = newGoal.copy(dailyCalorieLimit = finalLimit)
            repository.insertUserGoal(newGoal)
        }
    }

    fun resetDailyLogs() {
        viewModelScope.launch {
            // Delete today's logs for testing
            val list = allCalorieEntries.value.filter { isToday(it.timestamp) }
            list.forEach { repository.deleteCalorieEntryById(it.id) }
        }
    }

    // --- Helper math logic ---

    private fun isToday(time: Long): Boolean {
        return DateUtils.isToday(time)
    }

    private fun calculateMifflinLimit(goal: UserGoal): Int {
        // Mifflin-St Jeor Equation
        // Men: BMR = 10 * weight (kg) + 6.25 * height (cm) - 5 * age (y) + 5
        // Women: BMR = 10 * weight (kg) + 6.25 * height (cm) - 5 * age (y) - 161
        val bmr = if (goal.gender == "Kişi") {
            (10.0 * goal.weight) + (6.25 * goal.height) - (5.0 * goal.age) + 5.0
        } else {
            (10.0 * goal.weight) + (6.25 * goal.height) - (5.0 * goal.age) - 161.0
        }

        val multiplier = when (goal.activityLevel) {
            "Hərəkətsiz" -> 1.2
            "Yüngül Aktiv" -> 1.375
            "Orta Aktiv" -> 1.55
            "Çox Aktiv" -> 1.725
            else -> 1.2
        }

        return (bmr * multiplier).toInt()
    }

    // --- Offline database & fallback logic ---

    private fun getOfflineFood(query: String): FoodNutritionResponse? {
        val q = query.lowercase().trim()
        return when {
            q == "alma" -> FoodNutritionResponse("Alma", "Meyvələr", 52, 0.3, 0.2, 14.0, "C, B6, Kaliyum", "Ürək sağlamlığını dəstəkləyir, liflə zəngindir və həzmə kömək edir.", "Hər gün alma yemək bədəni toksinlərdən təmizləyir və immun sistemini güclü saxlayır.")
            q == "banan" -> FoodNutritionResponse("Banan", "Meyvələr", 89, 1.1, 0.3, 23.0, "B6, C, Kalium", "Bədənə yüksək enerji verir və əzələ spazmlarını azaldır.", "Hər gün banan yemək təzyiqi tənzimləyir və gün boyu sizi enerjili saxlayır.")
            q == "portağal" -> FoodNutritionResponse("Portağal", "Meyvələr", 47, 0.9, 0.1, 12.0, "C, A, Kalsium", "İmmuniteti maksimum səviyyəyə qaldırır, dərini gözəlləşdirir.", "Hər gün portağal yemək qrip və soyuqdəymə ehtimalını minimuma salır.")
            q == "çiyələk" -> FoodNutritionResponse("Çiyələk", "Meyvələr", 32, 0.7, 0.3, 8.0, "C, Fol turşusu, Kaliyum", "Antioksidant deposudur, qan təzyiqini aşağı salır.", "Hər gün çiyələk yemək hüceyrələri qoruyur və zehni fəaliyyəti sürətləndirir.")
            
            q == "pomidor" -> FoodNutritionResponse("Pomidor", "Tərəvəzlər", 18, 0.9, 0.2, 3.9, "C, K, Likopen", "Likopen sayəsində xərçəng riskini azaldır və dəri cavanlığını qoruyur.", "Hər gün pomidor yemək ürəyi qoruyur və günəş şüalarından dərini müdafiə edir.")
            q == "xiyar" -> FoodNutritionResponse("Xiyar", "Tərəvəzlər", 15, 0.7, 0.1, 3.6, "K, C, Maqnezium", "95% sudan ibarətdir, bədəni nəmləndirir və artıq çəkini atmağa kömək edir.", "Hər gün xiyar yemək dərini parıldadır və böyrəkləri təmizləyir.")
            q == "brokoli" -> FoodNutritionResponse("Brokoli", "Tərəvəzlər", 34, 2.8, 0.4, 7.0, "C, K, Lif, Kalsium", "Sümük sıxlığını artırır, qan şəkərini nizamlayır.", "Hər gün brokoli yemək orqanizmi toksinlərdən tam arındırır və həzmi sürətləndirir.")
            q == "kök" -> FoodNutritionResponse("Kök", "Tərəvəzlər", 41, 0.9, 0.2, 10.0, "A, K1, B6, Biotin", "A vitamini sayəsində göz sağlamlığı üçün əvəzedilməzdir.", "Hər gün kök yemək görmə qabiliyyətini gücləndirir və dərini bürüncləşdirir.")
            
            q == "hamburger" || q == "burger" -> FoodNutritionResponse("Hamburger", "Fast-Food", 295, 13.0, 14.0, 30.0, "B12, Dəmir, Sink", "Aclığı sürətlə yatırır və yüksək zülal mənbəyidir.", "Hər gün hamburger yemək artıq çəki artımına, damar tıxanıqlığına və xolesterola səbəb ola bilər.")
            q == "pizza" -> FoodNutritionResponse("Pizza", "Fast-Food", 266, 11.0, 10.0, 33.0, "Kalsium, B12, Sink", "İctimai yemək zövqü verir və sürətli doyum hissi bəxş edir.", "Hər gün pizza yemək yüksək natrium və doymuş yağ səbəbindən ürək xəstəlikləri riskini çoxaldır.")
            q == "lahmacun" -> FoodNutritionResponse("Lahmacun", "Fast-Food", 220, 9.5, 8.0, 27.0, "B-kompleks, Dəmir", "Nazik xəmiri və qıyması ilə nisbətən yüngül fast-food seçimidir.", "Hər gün lahmacun yemək həzm sistemini yorur və duz miqdarı çox olduğundan təzyiqi artırır.")
            q == "dönər" -> FoodNutritionResponse("Dönər", "Fast-Food", 310, 18.0, 15.0, 25.0, "B6, B12, Dəmir", "Yüksək enerji və əzələ quruculuğu üçün kifayət qədər bol protein təmin edir.", "Hər gün dönər yemək doymuş yağ yığılmasına və artıq çəkiyə gətirib çıxarır.")
            q == "kartof fri" || q == "kartof paraları" -> FoodNutritionResponse("Kartof Fri", "Fast-Food", 312, 3.4, 15.0, 41.0, "B6, Kaliyum", "Sürətli karbonhidrat və ləzzətli duzlu qəlyanaltıdır.", "Hər gün kartof fri yemək damarların tutulmasına, çəki artımına və şəkər riskinə gətirib çıxarır.")
            
            else -> null
        }
    }

    private fun generateMockFood(query: String): FoodNutritionResponse {
        // Parse basic keywords to guess category
        val lower = query.lowercase()
        val category: String
        val cals: Int
        val prot: Double
        val fat: Double
        val carb: Double
        val vit: String
        val ben: String
        val cons: String

        when {
            lower.contains("alma") || lower.contains("banan") || lower.contains("gilas") || lower.contains("şaftalı") ||
                    lower.contains("armud") || lower.contains("nar") || lower.contains("çiyələk") || lower.contains("üzüm") ||
                    lower.contains("meyvə") || lower.contains("qarpız") || lower.contains("yemiş") -> {
                category = "Meyvələr"
                cals = kotlin.random.Random.nextInt(40, 91)
                prot = kotlin.random.Random.nextDouble(0.5, 1.5)
                fat = kotlin.random.Random.nextDouble(0.1, 0.4)
                carb = kotlin.random.Random.nextInt(10, 23).toDouble()
                vit = "A, C, Kalium"
                ben = "Həzmi asanlaşdırır, liflə və güclü antioksidantlarla zəngindir."
                cons = "Hər gün natural olaraq qəbul edilməsi bədəni nəmli saxlayır və lif ehtiyacını ödəyir."
            }
            lower.contains("pomidor") || lower.contains("xiyar") || lower.contains("kələm") || lower.contains("kök") ||
                    lower.contains("ispanaq") || lower.contains("göyərti") || lower.contains("brokoli") ||
                    lower.contains("bibər") || lower.contains("tərəvəz") || lower.contains("badımcan") -> {
                category = "Tərəvəzlər"
                cals = kotlin.random.Random.nextInt(15, 46)
                prot = kotlin.random.Random.nextDouble(0.8, 3.0)
                fat = kotlin.random.Random.nextDouble(0.0, 0.3)
                carb = kotlin.random.Random.nextInt(3, 9).toDouble()
                vit = "K, A, C, Maqnezium"
                ben = "Aşağı kalorili qidadır, maddələr mübadiləsini sürətləndirir və dərini bərpa edir."
                cons = "Hər gün tərəvəz yemək çəkini nizamda saxlayır və vitaminsiz qalmağın qarşısını alır."
            }
            lower.contains("hamburger") || lower.contains("burger") || lower.contains("pizza") || lower.contains("lahmacun") ||
                    lower.contains("dönər") || lower.contains("kartof fri") || lower.contains("nugget") ||
                    lower.contains("fast") || lower.contains("hotdog") || lower.contains("kabab") -> {
                category = "Fast-Food"
                cals = kotlin.random.Random.nextInt(230, 421)
                prot = kotlin.random.Random.nextInt(8, 23).toDouble()
                fat = kotlin.random.Random.nextInt(10, 25).toDouble()
                carb = kotlin.random.Random.nextInt(20, 46).toDouble()
                vit = "B12, Na, Dəmir"
                ben = "Sürətli enerji verir və dad reseptorlarını ləzzətlə doydurur."
                cons = "Hər gün fast-food qəbul etmək çəkini sürətlə artırır, ürəyi yorur və trans-yağ zərəri vurur."
            }
            else -> {
                category = "Digər"
                cals = kotlin.random.Random.nextInt(120, 351)
                prot = kotlin.random.Random.nextInt(2, 16).toDouble()
                fat = kotlin.random.Random.nextInt(1, 19).toDouble()
                carb = kotlin.random.Random.nextInt(10, 41).toDouble()
                vit = "B-Kompleks, Protein, Sink"
                ben = "Gündəlik qida rasionunun bərpası üçün zəruri karbonhidrat və zülal tərkibinə malikdir."
                cons = "Hər gün nizamlı və porsiyalara bölünərək yeyildikdə gündəlik aktiv enerjini qoruyur."
            }
        }

        // Return standardized dynamic payload with Azerbaijani texts
        return FoodNutritionResponse(
            name = query.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() },
            category = category,
            calories = cals,
            protein = "%.1f".format(prot).replace(",", ".").toDoubleOrNull() ?: 1.0,
            fat = "%.1f".format(fat).replace(",", ".").toDoubleOrNull() ?: 0.5,
            carbs = "%.1f".format(carb).replace(",", ".").toDoubleOrNull() ?: 15.0,
            vitamins = vit,
            benefits = ben,
            consequences = cons
        )
    }
}

class TrackerViewModelFactory(private val repository: TrackerRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TrackerViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return TrackerViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
