package com.example.ui.screens

import android.text.format.DateFormat
import android.widget.Space
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.CalorieEntry
import com.example.data.WeightEntry
import com.example.data.UserGoal
import com.example.network.FoodNutritionResponse
import com.example.ui.SearchState
import com.example.ui.TrackerViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun MainScreen(
    viewModel: TrackerViewModel,
    onNavigateToDetail: (FoodNutritionResponse) -> Unit,
    modifier: Modifier = Modifier
) {
    var currentTab by remember { mutableStateOf(0) } // 0: Diary, 1: Analytics

    Scaffold(
        modifier = modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("main_bottom_nav")
            ) {
                NavigationBarItem(
                    selected = currentTab == 0,
                    onClick = { currentTab = 0 },
                    icon = { Icon(Icons.Filled.Restaurant, contentDescription = "Gündəlik") },
                    label = { Text("Gündəlik") },
                    modifier = Modifier.testTag("nav_diary")
                )
                NavigationBarItem(
                    selected = currentTab == 1,
                    onClick = { currentTab = 1 },
                    icon = { Icon(Icons.Filled.ShowChart, contentDescription = "Analitika") },
                    label = { Text("Analitika") },
                    modifier = Modifier.testTag("nav_analytics")
                )
            }
        }
    ) { innerPadding ->
        Crossfade(
            targetState = currentTab,
            animationSpec = tween(400, easing = EaseInOutCubic),
            modifier = Modifier.padding(innerPadding)
        ) { tab ->
            when (tab) {
                0 -> DiaryTab(viewModel = viewModel, onNavigateToDetail = onNavigateToDetail)
                1 -> AnalyticsTab(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun DiaryTab(
    viewModel: TrackerViewModel,
    onNavigateToDetail: (FoodNutritionResponse) -> Unit
) {
    val context = LocalContext.current
    val todayTotal by viewModel.todayCalorieTotal.collectAsStateWithLifecycle()
    val todayLimitObj by viewModel.userGoal.collectAsStateWithLifecycle()
    val todayLimit = todayLimitObj.dailyCalorieLimit

    val protein by viewModel.todayProteinTotal.collectAsStateWithLifecycle()
    val fat by viewModel.todayFatTotal.collectAsStateWithLifecycle()
    val carbs by viewModel.todayCarbsTotal.collectAsStateWithLifecycle()

    val calorieLogs by viewModel.allCalorieEntries.collectAsStateWithLifecycle()
    val searchState by viewModel.searchState.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var selectedFoodForPeek by remember { mutableStateOf<FoodNutritionResponse?>(null) }
    var showGoalSettings by remember { mutableStateOf(false) }

    val todayEntries = remember(calorieLogs) {
        calorieLogs.filter { android.text.format.DateUtils.isToday(it.timestamp) }
    }

    // Suggested standard foods for quick selection
    val fruitsSuggestions = remember {
        listOf(
            FoodNutritionResponse("Alma", "Meyvələr", 52, 0.3, 0.2, 14.0, "C, B6, Kaliyum", "Ürək sağlamlığını dəstəkləyir, liflə zəngindir və həzmə kömək edir.", "Hər gün alma yemək bədəni toksinlərdən təmizləyir və immun sistemini güclü saxlayır."),
            FoodNutritionResponse("Banan", "Meyvələr", 89, 1.1, 0.3, 23.0, "B6, C, Kalium", "Bədənə yüksək enerji verir və əzələ spazmlarını azaldır.", "Hər gün banan yemək təzyiqi tənzimləyir və gün boyu sizi enerjili saxlayır."),
            FoodNutritionResponse("Portağal", "Meyvələr", 47, 0.9, 0.1, 12.0, "C, A, Kalsium", "İmmuniteti maksimum səviyyəyə qaldırır, dərini gözəlləşdirir.", "Hər gün portağal yemək qrip və soyuqdəymə ehtimalını minimuma salır.")
        )
    }

    val veggiesSuggestions = remember {
        listOf(
            FoodNutritionResponse("Pomidor", "Tərəvəzlər", 18, 0.9, 0.2, 3.9, "C, K, Likopen", "Likopen sayəsində xərçəng riskini azaldır və dəri cavanlığını qoruyur.", "Hər gün pomidor yemək ürəyi qoruyur və dərini müdafiə edir."),
            FoodNutritionResponse("Xiyar", "Tərəvəzlər", 15, 0.7, 0.1, 3.6, "K, C, Maqnezium", "95% sudan ibarətdir, bədəni nəmləndirir və arıqlamağa kömək edir.", "Hər gün xiyar yemək dərini parıldadır və böyrəkləri təmizləyir."),
            FoodNutritionResponse("Brokoli", "Tərəvəzlər", 34, 2.8, 0.4, 7.0, "C, K, Lif, Kalsium", "Sümük sıxlığını artırır, qan şəkərini nizamlayır.", "Hər gün brokoli yemək orqanizmi toksinlərdən təmizləyir.")
        )
    }

    val fastFoodSuggestions = remember {
        listOf(
            FoodNutritionResponse("Hamburger", "Fast-Food", 295, 13.0, 14.0, 30.0, "B12, Dəmir, Sink", "Aclığı sürətlə yatırır və yüksək zülal mənbəyidir.", "Hər gün hamburger yemək artıq çəkiyə və xolesterola səbəb ola bilər."),
            FoodNutritionResponse("Pizza", "Fast-Food", 266, 11.0, 10.0, 33.0, "Kalsium, B12, Sink", "İctimai yemək zövqü verir və sürətli doyum hissi bəxş edir.", "Hər gün pizza yemək fəsadlı doymuş yağlar səbəbindən ürək üçün zərərlidir."),
            FoodNutritionResponse("Lahmacun", "Fast-Food", 220, 9.5, 8.0, 27.0, "B-kompleks, Dəmir", "Nazik xəmiri və qıyması ilə nisbətən yüngül fast-food seçimidir.", "Hər gün lahmacun yemək həzm sistemini yorur və təzyiqi artırır.")
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Salam, Sağlam Həyat!",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Gündəlik kalori və qida izləyici",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(
                    onClick = { showGoalSettings = true },
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.primaryContainer, CircleShape)
                        .testTag("goal_settings_button")
                ) {
                    Icon(
                        Icons.Filled.Settings,
                        contentDescription = "Hədəf Tənzimləmələri",
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Animated Calorie Circular Progress & Summary Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.2f)) {
                        Text(
                            text = "Bugünkü Limitiniz",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$todayTotal / $todayLimit Kcal",
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
                            color = if (todayTotal > todayLimit) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        // Macros
                        MacroBar(label = "Zülal (Protein)", value = protein, target = 80.0, color = Color(0xFF4CAF50))
                        MacroBar(label = "Yağ (Fat)", value = fat, target = 65.0, color = Color(0xFFFF9800))
                        MacroBar(label = "Karbonhidrat (Carb)", value = carbs, target = 250.0, color = Color(0xFF2196F3))
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    // Circular Gauge
                    val percentage = remember(todayTotal, todayLimit) {
                        if (todayLimit > 0) (todayTotal.toFloat() / todayLimit.toFloat()).coerceIn(0f, 1.2f) else 0f
                    }
                    val animatedPercentage by animateFloatAsState(
                        targetValue = percentage,
                        animationSpec = tween(durationMillis = 1200, easing = EaseOutBack),
                        label = "progress"
                    )

                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(110.dp)
                            .padding(4.dp)
                    ) {
                        Canvas(modifier = Modifier.size(100.dp)) {
                            // Background line
                            drawArc(
                                color = Color.LightGray.copy(alpha = 0.3f),
                                startAngle = -220f,
                                sweepAngle = 260f,
                                useCenter = false,
                                style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
                            )
                            // Animated colored track
                            drawArc(
                                brush = Brush.sweepGradient(
                                    listOf(
                                        Color(0xFF81C784),
                                        Color(0xFFFFB74D),
                                        Color(0xFFE57373)
                                    )
                                ),
                                startAngle = -220f,
                                sweepAngle = animatedPercentage * 260f,
                                useCenter = false,
                                style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${(percentage * 100).toInt()}%",
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = if (todayTotal > todayLimit) "Aşılıb" else "Qalıb",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (todayTotal > todayLimit) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Search Foods Section with Gemini AI
            Text(
                text = "Hər Hansı Qidanı Axtar",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(top = 8.dp)
            )

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Məsələn: alma, lahmacun, pomidor...") },
                placeholder = { Text("Qidanın adını daxil edin") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = ""; viewModel.clearSearch() }) {
                            Icon(Icons.Filled.Close, contentDescription = "Təmizlə")
                        }
                    }
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("food_search_bar"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                )
            )

            // Search action button / Gemini dynamic search trigger
            Button(
                onClick = { viewModel.searchFood(searchQuery) },
                enabled = searchQuery.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("food_search_submit_button"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Filled.AutoAwesome, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Süni İntellektlə Təhlil Et (Gemini)")
            }

            // Search Loading or Result Cards
            AnimatedVisibility(
                visible = searchState !is SearchState.Idle,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        when (val state = searchState) {
                            is SearchState.Loading -> {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    CircularProgressIndicator(modifier = Modifier.size(36.dp))
                                    Text(
                                        text = "Gemini qidanı analiz edir...",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                            is SearchState.Success -> {
                                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = state.food.name,
                                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                                color = MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                            Text(
                                                text = "Kateqoriya: ${state.food.category}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Badge(
                                            containerColor = when (state.food.category) {
                                                "Meyvələr" -> Color(0xFF4CAF50)
                                                "Tərəvəzlər" -> Color(0xFF8BC34A)
                                                "Fast-Food" -> Color(0xFFF44336)
                                                else -> MaterialTheme.colorScheme.secondary
                                            },
                                            modifier = Modifier.padding(horizontal = 8.dp)
                                        ) {
                                            Text(
                                                text = "${state.food.calories} Kcal",
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(4.dp)
                                            )
                                        }
                                    }

                                    // Macros Mini values
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        MacroChip(label = "Zülal", value = "${state.food.protein}g")
                                        MacroChip(label = "Yağ", value = "${state.food.fat}g")
                                        MacroChip(label = "Carb", value = "${state.food.carbs}g")
                                    }

                                    Divider(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.1f))

                                    // Quick View instructions
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Button(
                                            onClick = { selectedFoodForPeek = state.food },
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("search_quick_peek_button"),
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                        ) {
                                            Text("Sürətli Əlavə Et")
                                        }
                                        OutlinedButton(
                                            onClick = { onNavigateToDetail(state.food) },
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("search_detailed_button")
                                        ) {
                                            Text("Detallı Gör")
                                        }
                                    }
                                }
                            }
                            is SearchState.Error -> {
                                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text(
                                        text = state.message,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                    Text(
                                        text = "Avtomatik olaraq quraşdırılmış mütəxəssis bazasından istifadə edilir.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                            }
                            else -> {}
                        }
                    }
                }
            }

            // 3 Categorized Compartments (Meyvələr, Tərəvəzlər, Fast-Food)
            Text(
                text = "Kataloqlar (Sürətli Qeyd üçün)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(top = 8.dp)
            )

            // Compartment 1: Meyvələr (Fruits) with custom generated hero card
            CategoryCardSection(
                title = "Meyvələr",
                bannerRes = R.drawable.fruits_banner,
                suggestions = fruitsSuggestions,
                accentColor = Color(0xFF4CAF50),
                onItemClick = { selectedFoodForPeek = it }
            )

            // Compartment 2: Tərəvəzlər (Vegetables)
            CategoryCardSection(
                title = "Tərəvəzlər",
                bannerRes = R.drawable.veggies_banner,
                suggestions = veggiesSuggestions,
                accentColor = Color(0xFF8BC34A),
                onItemClick = { selectedFoodForPeek = it }
            )

            // Compartment 3: Fast-Food
            CategoryCardSection(
                title = "Fast-Food",
                bannerRes = R.drawable.fast_food_banner,
                suggestions = fastFoodSuggestions,
                accentColor = Color(0xFFF44336),
                onItemClick = { selectedFoodForPeek = it }
            )

            // Gündəlik Log siyahısı (Today's food diary list)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Bugünkü Yeməklər",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                if (todayEntries.isNotEmpty()) {
                    TextButton(onClick = { viewModel.resetDailyLogs() }) {
                        Text("Hamısını Sil", color = MaterialTheme.colorScheme.error)
                    }
                }
            }

            if (todayEntries.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            Icons.Filled.RestaurantMenu,
                            contentDescription = null,
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.outline
                        )
                        Text(
                            text = "Hələ qida daxil edilməyib",
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
                            color = MaterialTheme.colorScheme.outline
                        )
                        Text(
                            text = "Yuxarıdakı axtarış panelindən və ya kataloqlardan istifadə edərək bu gün yediyiniz yeməkləri daxil edin.",
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            } else {
                todayEntries.forEach { entry ->
                    DiaryItemRow(entry = entry, onDelete = { viewModel.deleteLoggedCalorie(entry.id) })
                }
            }
        }

        // Quick Peek Animating Overlay Bottom Sheet (Qısa Pəncərə overlay)
        AnimatedVisibility(
            visible = selectedFoodForPeek != null,
            enter = slideInVertically(animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)) { h -> h } + fadeIn(),
            exit = slideOutVertically(animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)) { h -> h } + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            selectedFoodForPeek?.let { food ->
                QuickPeekPanel(
                    food = food,
                    onDismiss = { selectedFoodForPeek = null },
                    onNavigateToDetail = {
                        selectedFoodForPeek = null
                        onNavigateToDetail(food)
                    },
                    onAdd = { multiplier ->
                        viewModel.logCalorie(
                            name = food.name,
                            calories = (food.calories * multiplier).toInt(),
                            category = food.category,
                            p = food.protein * multiplier,
                            f = food.fat * multiplier,
                            c = food.carbs * multiplier,
                            b = food.benefits,
                            cons = food.consequences,
                            vit = food.vitamins
                        )
                        selectedFoodForPeek = null
                    }
                )
            }
        }

        // Goal settings dialog
        if (showGoalSettings) {
            GoalSettingsDialog(
                currentGoal = todayLimitObj,
                onDismiss = { showGoalSettings = false },
                onSave = { updatedCalorie, isAuto, weight, height, age, gender, activity ->
                    viewModel.updateGoal(updatedCalorie, isAuto, weight, height, age, gender, activity)
                    showGoalSettings = false
                }
            )
        }
    }
}

@Composable
fun CategoryCardSection(
    title: String,
    bannerRes: Int,
    suggestions: List<FoodNutritionResponse>,
    accentColor: Color,
    onItemClick: (FoodNutritionResponse) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Background generated image
            Image(
                painter = painterResource(id = bannerRes),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Dark Overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f)),
                            startY = 100f
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Category Title Shield
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(accentColor, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = title,
                        color = Color.White,
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }

                // Horizontal scrollable quick clickable foods list
                Column {
                    Text(
                        text = "Sürətli Seçim:",
                        color = Color.White.copy(alpha = 0.8f),
                        style = MaterialTheme.typography.labelSmall
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        suggestions.forEach { food ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color.White.copy(alpha = 0.82f),
                                modifier = Modifier
                                    .clickable { onItemClick(food) }
                                    .testTag("catalogue_${food.name.lowercase()}"),
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Outlined.AddCircle,
                                        contentDescription = null,
                                        tint = accentColor,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = food.name,
                                        color = Color.Black,
                                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${food.calories} kcal",
                                        color = Color.DarkGray,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DiaryItemRow(entry: CalorieEntry, onDelete: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(
                            color = when (entry.category) {
                                "Meyvələr" -> Color(0xFFE8F5E9)
                                "Tərəvəzlər" -> Color(0xFFF1F8E9)
                                "Fast-Food" -> Color(0xFFFFEBEE)
                                else -> Color(0xFFECEFF1)
                            },
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (entry.category) {
                            "Meyvələr" -> Icons.Filled.Spa
                            "Tərəvəzlər" -> Icons.Filled.Eco
                            "Fast-Food" -> Icons.Filled.Fastfood
                            else -> Icons.Filled.Restaurant
                        },
                        contentDescription = null,
                        tint = when (entry.category) {
                            "Meyvələr" -> Color(0xFF4CAF50)
                            "Tərəvəzlər" -> Color(0xFF8BC34A)
                            "Fast-Food" -> Color(0xFFF44336)
                            else -> Color(0xFF607D8B)
                        }
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = entry.name,
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Row(
                        modifier = Modifier.padding(top = 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "${entry.calories} Kcal",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Z: ${"%.1f".format(entry.protein)}g • Y: ${"%.1f".format(entry.fat)}g • K: ${"%.1f".format(entry.carbs)}g",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            }

            IconButton(onClick = onDelete) {
                Icon(
                    Icons.Filled.DeleteOutline,
                    contentDescription = "Sil",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

@Composable
fun MacroBar(label: String, value: Double, target: Double, color: Color) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("${"%.1f".format(value)} / ${target.toInt()}g", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(2.dp))
        val percent = if (target > 0) (value / target).toFloat().coerceIn(0f, 1f) else 0f
        LinearProgressIndicator(
            progress = percent,
            color = color,
            trackColor = color.copy(alpha = 0.2f),
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
        )
    }
}

@Composable
fun MacroChip(label: String, value: String) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
            Text(text = value, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
        }
    }
}

// --- Quick Peek Panel Slide-Up Layout ---

@Composable
fun QuickPeekPanel(
    food: FoodNutritionResponse,
    onDismiss: () -> Unit,
    onNavigateToDetail: () -> Unit,
    onAdd: (Double) -> Unit
) {
    var porsiyaMultiplier by remember { mutableStateOf(1.0) } // 1.0 means 100g or 1 piece

    // Semi-transparent dim background
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.4f))
            .clickable(
                onClick = onDismiss,
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ),
        contentAlignment = Alignment.BottomCenter
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(
                    onClick = {},
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) // prevent dismissing from tapping inside the card
                .testTag("quick_peek_card"),
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Dismiss Bar dragging design
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .size(40.dp, 4.dp)
                        .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), CircleShape)
                )

                // Title info
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = food.name,
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold)
                        )
                        Text(
                            text = "Kateqoriya: ${food.category}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                    ) {
                        Icon(Icons.Filled.Close, contentDescription = "Baxışı Bağla")
                    }
                }

                // Core fast statistics
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f),
                            RoundedCornerShape(16.dp)
                        )
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Hesablanan Kalori",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "${(food.calories * porsiyaMultiplier).toInt()} Kcal",
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Zülal: ${"%.1f".format(food.protein * porsiyaMultiplier)}g",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Yağ: ${"%.1f".format(food.fat * porsiyaMultiplier)}g",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Karb: ${"%.1f".format(food.carbs * porsiyaMultiplier)}g",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Slider / quantity gauge
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Porsiya Ölçüsü (Nisbəti)",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "${(porsiyaMultiplier * 100).toInt()}% (məs., ${(porsiyaMultiplier * 100).toInt()} qram)",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Slider(
                        value = porsiyaMultiplier.toFloat(),
                        onValueChange = { porsiyaMultiplier = it.toDouble() },
                        valueRange = 0.5f..5.0f,
                        steps = 8,
                        modifier = Modifier.testTag("portion_slider")
                    )
                }

                // Primary actions: Log directly, detailed review
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = { onNavigateToDetail() },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("peek_detailed_btn")
                    ) {
                        Icon(Icons.Filled.Info, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Detallı Gör")
                    }
                    Button(
                        onClick = { onAdd(porsiyaMultiplier) },
                        modifier = Modifier
                            .weight(1.2f)
                            .height(52.dp)
                            .testTag("peek_add_diary_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Gündəliyə Əlavə Et")
                    }
                }
            }
        }
    }
}

// --- Analytics Tab Panel ---

@Composable
fun AnalyticsTab(viewModel: TrackerViewModel) {
    val weightLogs by viewModel.allWeightEntries.collectAsStateWithLifecycle()
    var inputWeight by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Çəki Analitika Paneli",
            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = "Bədən çəki dəyişikliyini analitik qrafiklərlə real zamanlı izləyin.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        // Graph Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Çəki Dəyişim Qrafiki (Trend)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Icon(
                        Icons.Filled.Leaderboard,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Line graph
                WeightTrendGraph(weightEntries = weightLogs)
            }
        }

        // Add Weight log card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Yeni Çəki Qeyd Et",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = inputWeight,
                        onValueChange = { inputWeight = it },
                        label = { Text("Məsələn: 72.5") },
                        suffix = { Text("kq") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("weight_input")
                    )

                    Button(
                        onClick = {
                            val w = inputWeight.toDoubleOrNull()
                            if (w != null) {
                                viewModel.logWeight(w)
                                inputWeight = ""
                            }
                        },
                        enabled = inputWeight.toDoubleOrNull() != null,
                        modifier = Modifier
                            .height(56.dp)
                            .testTag("save_weight_button")
                    ) {
                        Text("Qeyd Et")
                    }
                }
            }
        }

        // Historial of Weights List
        Text(
            text = "Son Qeydlər",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            modifier = Modifier.padding(top = 8.dp)
        )

        if (weightLogs.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Heç bir çəki qeydi yoxdur",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }
        } else {
            weightLogs.sortedBy { it.timestamp }.reversed().forEach { log ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Filled.Scale,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "${log.weight} kq",
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = formatDate(log.timestamp),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }
                        }

                        IconButton(onClick = { viewModel.deleteWeightLog(log.id) }) {
                            Icon(
                                Icons.Filled.DeleteOutline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WeightTrendGraph(weightEntries: List<WeightEntry>) {
    if (weightEntries.size < 2) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .background(
                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    RoundedCornerShape(16.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    Icons.Filled.TrendingUp,
                    contentDescription = null,
                    modifier = Modifier.size(40.dp),
                    tint = MaterialTheme.colorScheme.outline
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Qrafik üçün ən azı 2 qeyd əlavə edin",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline
                )
            }
        }
        return
    }

    val sortedPoints = remember(weightEntries) { weightEntries.sortedBy { it.timestamp } }
    val maxWeight = remember(sortedPoints) { sortedPoints.maxOf { it.weight } }
    val minWeight = remember(sortedPoints) { sortedPoints.minOf { it.weight } }
    val weightRange = remember(maxWeight, minWeight) {
        val range = maxWeight - minWeight
        if (range == 0.0) 4.0 else range
    }

    val minScaleY = remember(minWeight, weightRange) { minWeight - (weightRange * 0.15) }
    val maxScaleY = remember(maxWeight, weightRange) { maxWeight + (weightRange * 0.15) }
    val actualRangeY = maxScaleY - minScaleY

    // Animated path drawing values
    val pathAnim = remember { Animatable(0f) }
    LaunchedEffect(sortedPoints) {
        pathAnim.snapTo(0f)
        pathAnim.animateTo(1.5f, animationSpec = tween(durationMillis = 1200, easing = EaseInOutQuart))
    }

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
            .padding(horizontal = 12.dp, vertical = 24.dp)
    ) {
        val width = size.width
        val height = size.height

        val stepX = width / (sortedPoints.size - 1)

        val coordinates = sortedPoints.mapIndexed { index, point ->
            val ratioY = (point.weight - minScaleY) / actualRangeY
            val x = index * stepX
            val y = height - (ratioY * height).toFloat()
            Offset(x, y)
        }

        // Draw horizontal grid lines
        val gridLinesCount = 3
        for (i in 0..gridLinesCount) {
            val y = height * i / gridLinesCount
            drawLine(
                color = Color.LightGray.copy(alpha = 0.4f),
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 1.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
            )
        }

        // Build continuous path
        val strokePath = Path()
        val fillPath = Path()

        coordinates.forEachIndexed { index, coord ->
            if (index == 0) {
                strokePath.moveTo(coord.x, coord.y)
                fillPath.moveTo(coord.x, height)
                fillPath.lineTo(coord.x, coord.y)
            } else {
                strokePath.lineTo(coord.x, coord.y)
                fillPath.lineTo(coord.x, coord.y)
                if (index == coordinates.lastIndex) {
                    fillPath.lineTo(coord.x, height)
                }
            }
        }

        // Draw dynamic under-fill gradient
        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF2196F3).copy(alpha = 0.35f),
                    Color(0xFF2196F3).copy(alpha = 0.0f)
                )
            )
        )

        // Draw animated main Trend Line
        drawPath(
            path = strokePath,
            color = Color(0xFF1E88E5),
            style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
        )

        // Highlight Data Points / Circles
        coordinates.forEachIndexed { _, coord ->
            drawCircle(
                color = Color.White,
                radius = 6.dp.toPx(),
                center = coord
            )
            drawCircle(
                color = Color(0xFF1E88E5),
                radius = 4.dp.toPx(),
                center = coord,
                style = Stroke(width = 2.dp.toPx())
            )
        }
    }
}

// --- Goal Settings Dialog Modal ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoalSettingsDialog(
    currentGoal: UserGoal,
    onDismiss: () -> Unit,
    onSave: (Int, Boolean, Double, Double, Int, String, String) -> Unit
) {
    var calorieInput by remember { mutableStateOf(currentGoal.dailyCalorieLimit.toString()) }
    var isAuto by remember { mutableStateOf(currentGoal.isAutoCalculate) }
    var weightInput by remember { mutableStateOf(currentGoal.weight.toString()) }
    var heightInput by remember { mutableStateOf(currentGoal.height.toString()) }
    var ageInput by remember { mutableStateOf(currentGoal.age.toString()) }
    var genderSelect by remember { mutableStateOf(currentGoal.gender) }
    var activitySelect by remember { mutableStateOf(currentGoal.activityLevel) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .testTag("goal_settings_dialog"),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Gündəlik Hədəf Tənzimlə",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )

                // Is Auto calculation checkbox
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .clickable { isAuto = !isAuto }
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Avtomatik Limit Hesabla",
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Bədən parametrlərinizə əsasən Mifflin-St Jeor düsturu ilə təyin olunur.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                    Switch(
                        checked = isAuto,
                        onCheckedChange = { isAuto = it },
                        modifier = Modifier.testTag("auto_calc_switch")
                    )
                }

                if (!isAuto) {
                    OutlinedTextField(
                        value = calorieInput,
                        onValueChange = { calorieInput = it },
                        label = { Text("Gündəlik Kalori Limiti (Kcal)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("man_calorie_input")
                    )
                } else {
                    // Profile Info Inputs
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedTextField(
                                value = weightInput,
                                onValueChange = { weightInput = it },
                                label = { Text("Çəki (Kq)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = heightInput,
                                onValueChange = { heightInput = it },
                                label = { Text("Boy (Sm)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        OutlinedTextField(
                            value = ageInput,
                            onValueChange = { ageInput = it },
                            label = { Text("Yaş") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Gender Radio Group
                        Text("Cinsiyyət", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(20.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = genderSelect == "Kişi", onClick = { genderSelect = "Kişi" })
                                Text("Kişi")
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = genderSelect == "Qadın", onClick = { genderSelect = "Qadın" })
                                Text("Qadın")
                            }
                        }

                        // Activity Selection
                        Text("Aktivlik Səviyyəsi", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        val activities = listOf("Hərəkətsiz", "Yüngül Aktiv", "Orta Aktiv", "Çox Aktiv")
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            activities.forEach { act ->
                                FilterChip(
                                    selected = activitySelect == act,
                                    onClick = { activitySelect = act },
                                    label = { Text(act) }
                                )
                            }
                        }
                    }
                }

                // CTA Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Ləğv Et")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val cal = calorieInput.toIntOrNull() ?: 2000
                            val wt = weightInput.toDoubleOrNull() ?: 70.0
                            val ht = heightInput.toDoubleOrNull() ?: 175.0
                            val age = ageInput.toIntOrNull() ?: 25
                            onSave(cal, isAuto, wt, ht, age, genderSelect, activitySelect)
                        },
                        modifier = Modifier.testTag("save_dialog_btn")
                    ) {
                        Text("Yadda Saxla")
                    }
                }
            }
        }
    }
}

// --- General Utility Formatter Function ---

private fun formatDate(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("az"))
    return sdf.format(Date(timestamp))
}
