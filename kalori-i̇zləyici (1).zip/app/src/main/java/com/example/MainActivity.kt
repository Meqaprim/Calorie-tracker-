package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.TrackerDatabase
import com.example.data.TrackerRepository
import com.example.network.FoodNutritionResponse
import com.example.ui.TrackerViewModel
import com.example.ui.TrackerViewModelFactory
import com.example.ui.screens.FoodDetailScreen
import com.example.ui.screens.MainScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Core room persistence instantiations
        val database = TrackerDatabase.getDatabase(this)
        val repository = TrackerRepository(database.trackerDao())

        setContent {
            MyApplicationTheme {
                val navController = rememberNavController()
                val viewModel: TrackerViewModel = viewModel(
                    factory = TrackerViewModelFactory(repository)
                )

                // Shared state holder for deep-dive detailed view
                var selectedDetailedFood by remember { mutableStateOf<FoodNutritionResponse?>(null) }

                NavHost(
                    navController = navController,
                    startDestination = "main"
                ) {
                    composable("main") {
                        MainScreen(
                            viewModel = viewModel,
                            onNavigateToDetail = { food ->
                                selectedDetailedFood = food
                                navController.navigate("food_detail")
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    composable("food_detail") {
                        selectedDetailedFood?.let { food ->
                            FoodDetailScreen(
                                viewModel = viewModel,
                                food = food,
                                onNavigateBack = {
                                    navController.popBackStack()
                                }
                            )
                        } ?: LaunchedEffect(Unit) {
                            navController.navigate("main") {
                                popUpTo("main") { inclusive = true }
                            }
                        }
                    }
                }
            }
        }
    }
}
