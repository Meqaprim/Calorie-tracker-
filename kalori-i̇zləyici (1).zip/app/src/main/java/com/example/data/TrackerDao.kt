package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TrackerDao {

    // --- Calorie Entries ---
    @Query("SELECT * FROM calorie_entries ORDER BY timestamp DESC")
    fun getAllCalorieEntries(): Flow<List<CalorieEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCalorieEntry(entry: CalorieEntry)

    @Query("DELETE FROM calorie_entries WHERE id = :id")
    suspend fun deleteCalorieEntryById(id: Int)

    @Query("DELETE FROM calorie_entries")
    suspend fun clearAllCalorieEntries()

    // --- Weight Entries ---
    @Query("SELECT * FROM weight_entries ORDER BY timestamp ASC")
    fun getAllWeightEntries(): Flow<List<WeightEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeightEntry(entry: WeightEntry)

    @Query("DELETE FROM weight_entries WHERE id = :id")
    suspend fun deleteWeightEntryById(id: Int)

    // --- User Goal ---
    @Query("SELECT * FROM user_goals WHERE id = 1 LIMIT 1")
    fun getUserGoalFlow(): Flow<UserGoal?>

    @Query("SELECT * FROM user_goals WHERE id = 1 LIMIT 1")
    suspend fun getUserGoal(): UserGoal?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserGoal(goal: UserGoal)
}
