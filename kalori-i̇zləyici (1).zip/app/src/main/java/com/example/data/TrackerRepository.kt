package com.example.data

import kotlinx.coroutines.flow.Flow

class TrackerRepository(private val trackerDao: TrackerDao) {

    val allCalorieEntries: Flow<List<CalorieEntry>> = trackerDao.getAllCalorieEntries()
    val allWeightEntries: Flow<List<WeightEntry>> = trackerDao.getAllWeightEntries()
    val userGoalFlow: Flow<UserGoal?> = trackerDao.getUserGoalFlow()

    suspend fun insertCalorieEntry(entry: CalorieEntry) {
        trackerDao.insertCalorieEntry(entry)
    }

    suspend fun deleteCalorieEntryById(id: Int) {
        trackerDao.deleteCalorieEntryById(id)
    }

    suspend fun clearAllCalorieEntries() {
        trackerDao.clearAllCalorieEntries()
    }

    suspend fun insertWeightEntry(entry: WeightEntry) {
        trackerDao.insertWeightEntry(entry)
    }

    suspend fun deleteWeightEntryById(id: Int) {
        trackerDao.deleteWeightEntryById(id)
    }

    suspend fun getUserGoal(): UserGoal? {
        return trackerDao.getUserGoal()
    }

    suspend fun insertUserGoal(goal: UserGoal) {
        trackerDao.insertUserGoal(goal)
    }
}
