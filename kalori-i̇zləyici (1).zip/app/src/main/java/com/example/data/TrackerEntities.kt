package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "calorie_entries")
data class CalorieEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val calories: Int,
    val category: String, // "Meyvələr", "Tərəvəzlər", "Fast-Food", "Digər"
    val timestamp: Long = System.currentTimeMillis(),
    val protein: Double = 0.0,
    val fat: Double = 0.0,
    val carbs: Double = 0.0,
    val benefits: String? = null,
    val consequences: String? = null,
    val vitamins: String? = null
)

@Entity(tableName = "weight_entries")
data class WeightEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val weight: Double,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_goals")
data class UserGoal(
    @PrimaryKey val id: Int = 1, // Single-row entity
    val dailyCalorieLimit: Int = 2000,
    val isAutoCalculate: Boolean = false,
    val weight: Double = 70.0,
    val height: Double = 175.0,
    val age: Int = 25,
    val gender: String = "Kişi", // "Kişi" or "Qadın"
    val activityLevel: String = "Orta Aktiv" // "Hərəkətsiz", "Yüngül Aktiv", "Orta Aktiv", "Çox Aktiv"
)
